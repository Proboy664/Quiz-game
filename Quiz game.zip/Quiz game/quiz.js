let score = 0;
let get = prompt("Set the score you will on correct answer(required)");
let btn = document.getElementById("sub")
let dialog = document.querySelector("dialog")

let gg = 0;

function done() {
    
  if (gg !== 9) {

    let div = document.createElement("div")
    let p = document.createElement("p")
    let btn1 = document.createElement("button")
    let btn2 = document.createElement("button")
    let btn3 = document.createElement("button")
    let btn4 = document.createElement("button")

    div.className = 'box'

    p.innerText = document.getElementById("inp1").value
    btn1.innerText = document.getElementById("inp2").value
    btn2.innerText = document.getElementById("inp3").value
    btn3.innerText = document.getElementById("inp4").value
    btn4.innerText = document.getElementById("inp5").value


    div.appendChild(p);
    div.appendChild(btn1)
    div.appendChild(btn2)
    div.appendChild(btn3)
    div.appendChild(btn4)
    
    document.getElementById("con").appendChild(div)

    dialog.close();

   let ch1 = document.getElementById("check1")
   let ch2 = document.getElementById("check2")
   let ch3 = document.getElementById("check3")
   let ch4 = document.getElementById("check4")  

   btn1.className = btn2.className = btn3.className = btn4.className = 'op';

    
   if (ch1 && ch1.checked) {
    btn1.className = 'op1';
    btn1.id = gg;
    }
   else if (ch2 && ch2.checked) {
    btn2.className = 'op1';
    btn2.id = gg;
   }
   else if (ch3 && ch3.checked) {
    btn3.className = 'op1';
    btn3.id = gg;
   }
   else if (ch4 && ch4.checked) {
    btn4.className = 'op1';
    btn4.id = gg;
   }

   gg += 1;
}    
  if (gg === 9) {
    dialog.close(); 
  document.getElementById("add").disabled = true;
  alert("You have reached the maximum limit to add questions");
}
}
  
function add() {
    dialog.showModal();
   
  document.getElementById("inp1").value = " ";
  document.getElementById("inp2").value = " "; 
  document.getElementById("inp3").value = " "; 
  document.getElementById("inp4").value = " "; 
  document.getElementById("inp5").value = " ";

  document.getElementById("check1").checked = false;
  document.getElementById("check2").checked = false;
  document.getElementById("check3").checked = false;
  document.getElementById("check4").checked = false;  
}


function  start() {
  
  dialog.close();
  document.getElementById("add").disabled = true;
   

  document.getElementById("0").addEventListener("click", function() { 

    document.getElementById("0").disabled = true;
    score += get;
})
  document.getElementById("1").addEventListener("click", function() {

    document.getElementById("1").disabled = true;
    score += get;
})
  document.getElementById("2").addEventListener("click", function() {

    document.getElementById("2").disabled = true;
    score += get;
})
  document.getElementById("3").addEventListener("click", function() {  

    document.getElementById("3").disabled = true;
    score += get;
})
  document.getElementById("4").addEventListener("click", function() {  

    document.getElementById("4").disabled = true;
    score += get;
})
  document.getElementById("5").addEventListener("click", function() {  

    document.getElementById("5").disabled = true;
    score += get;
})
  document.getElementById("6").addEventListener("click", function() {  

    document.getElementById("6").disabled = true;
    score += get;
})
  document.getElementById("7").addEventListener("click", function() {  

    document.getElementById("7").disabled = true;
    score += get;
})
  document.getElementById("8").addEventListener("click", function() {  

    document.getElementById("8").disabled = true;
    score += get;
  })}

function  sub() {
  alert("You got: " + score + " Out of " + gg + " questions")
  location.reload()
}